-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 01, 2025 at 01:27 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kpis`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Username` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`ID`, `Name`, `Username`, `Password`, `created_at`) VALUES
(10, 'Chris Paolo Vivo', 'sample user', '123456789', '2024-12-07 03:06:29');

-- --------------------------------------------------------

--
-- Table structure for table `cart_tbl`
--

CREATE TABLE `cart_tbl` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `fileUpload` varchar(255) DEFAULT NULL,
  `order_id` int(11) NOT NULL,
  `layout_size` varchar(50) DEFAULT NULL,
  `paper_type` varchar(50) DEFAULT NULL,
  `copies` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `print_type` enum('bw','colored') DEFAULT NULL,
  `file_upload` varchar(255) DEFAULT NULL,
  `thickness` varchar(10) DEFAULT NULL,
  `photo_size` varchar(10) DEFAULT NULL,
  `order_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `id_type` varchar(255) DEFAULT NULL,
  `service_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `user_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `gender` enum('male','female','other') NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `verification_code` int(11) NOT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`user_id`, `customer_name`, `email`, `password`, `created_at`, `gender`, `date_of_birth`, `phone_number`, `address`, `profile_picture`, `verification_code`, `is_verified`) VALUES
(19, 'Kristan Perez', 'kristan13ko@gmail.com', '123456789', '2024-12-15 16:46:44', 'male', NULL, '0903748368', '45th, Bagumbayan, Taguig City, 1630', 'uploads/Research_and_extension.png', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `deliver_tbl`
--

CREATE TABLE `deliver_tbl` (
  `delivery_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `delivery_address` text DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `delivery_status` varchar(50) NOT NULL,
  `tracking_number` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inventory_tbl`
--

CREATE TABLE `inventory_tbl` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `inventory_tbl`
--

INSERT INTO `inventory_tbl` (`item_id`, `item_name`, `quantity`, `created_at`) VALUES
(1, 'Bond paper', 500, '2024-12-07 16:01:58'),
(8, 'Laminating Film', 121, '2024-12-07 21:02:35'),
(9, 'Photo Ink', 200, '2024-12-07 21:12:04'),
(10, 'Imaging Paper', 500, '2024-12-07 21:12:41');

-- --------------------------------------------------------

--
-- Table structure for table `order_tbl`
--

CREATE TABLE `order_tbl` (
  `order_id2` int(11) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `picture_name` varchar(255) NOT NULL,
  `picture_path` varchar(255) NOT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp(),
  `status` varchar(50) NOT NULL DEFAULT 'Pending',
  `order_date` datetime DEFAULT current_timestamp(),
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `fileUpload` varchar(255) DEFAULT NULL,
  `layout_size` varchar(50) DEFAULT NULL,
  `paper_type` varchar(50) DEFAULT NULL,
  `copies` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `print_type` enum('bw','colored') DEFAULT NULL,
  `file_upload` varchar(255) DEFAULT NULL,
  `thickness` varchar(10) DEFAULT NULL,
  `photo_size` varchar(10) DEFAULT NULL,
  `order_notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `user_id` int(11) DEFAULT NULL,
  `id_type` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_tbl`
--

INSERT INTO `order_tbl` (`order_id2`, `customer_name`, `service_type`, `picture_name`, `picture_path`, `uploaded_at`, `status`, `order_date`, `quantity`, `price`, `type`, `fileUpload`, `layout_size`, `paper_type`, `copies`, `notes`, `print_type`, `file_upload`, `thickness`, `photo_size`, `order_notes`, `created_at`, `user_id`, `id_type`) VALUES
(2007, 'Kristan Perez', 'Printing', '', '', '2024-12-16 10:46:39', 'Pending', '2024-12-16 10:46:39', NULL, 120.00, NULL, NULL, '0', 'Vinyl', 12, 'DFDSF', 'colored', 'uploads/chico 2.png', NULL, NULL, NULL, '2024-12-16 02:46:39', 19, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `payment_tbl`
--

CREATE TABLE `payment_tbl` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_date` datetime DEFAULT current_timestamp(),
  `payment_method` varchar(50) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `transaction_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_tbl`
--

INSERT INTO `payment_tbl` (`payment_id`, `order_id`, `payment_date`, `payment_method`, `payment_status`, `amount_paid`, `transaction_id`) VALUES
(1, 123, '2024-12-16 07:06:08', 'Credit Card', 'Pending', 642.00, 'TX1234567890'),
(2, 123, '2024-12-16 07:09:08', 'Credit Card', 'Pending', 642.00, 'TX1234567890'),
(3, 123, '2024-12-16 07:14:53', 'Credit Card', 'Pending', 642.00, 'TX1234567890'),
(4, 123, '2024-12-16 07:28:37', 'Credit Card', 'Pending', 150.00, 'TX1234567890'),
(5, 123, '2024-12-16 08:38:22', 'Credit Card', 'Pending', 150.00, 'TX1234567890'),
(6, 0, '2024-12-16 10:46:39', 'Credit Card', 'Completed', 150.00, 'TXN_675f948fb812b');

-- --------------------------------------------------------

--
-- Table structure for table `promotion_tbl`
--

CREATE TABLE `promotion_tbl` (
  `id` int(11) NOT NULL,
  `coupon_code` varchar(50) NOT NULL,
  `discount_value` int(11) NOT NULL,
  `expiry_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `promotion_tbl`
--

INSERT INTO `promotion_tbl` (`id`, `coupon_code`, `discount_value`, `expiry_date`) VALUES
(1, '14jsds2k3f', 20, '2025-01-08'),
(4, 'dka4s14ds', 10, '2025-01-26');

-- --------------------------------------------------------

--
-- Table structure for table `sc_tbl`
--

CREATE TABLE `sc_tbl` (
  `customization_id` int(11) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `customization_name` varchar(255) NOT NULL,
  `customization_description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sc_tbl`
--

INSERT INTO `sc_tbl` (`customization_id`, `service_type`, `customization_name`, `customization_description`, `price`, `created_at`) VALUES
(1, 'Print Service', 'Print Document', 'dasdas', 90.00, '2024-12-07 12:55:23'),
(2, 'Print documents', 'Print Document', 'erte', 10.00, '2024-12-07 13:07:18');

-- --------------------------------------------------------

--
-- Table structure for table `total_revenue`
--

CREATE TABLE `total_revenue` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `total_P` decimal(10,2) NOT NULL,
  `total_R` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `total_revenue`
--

INSERT INTO `total_revenue` (`id`, `date`, `total_P`, `total_R`) VALUES
(1, '2024-01-01', 15000.00, 12000.00),
(2, '2024-02-01', 17000.00, 13000.00),
(3, '2024-03-01', 18000.00, 14000.00),
(4, '2024-04-01', 19000.00, 15000.00),
(5, '2024-05-01', 20000.00, 16000.00),
(6, '2024-06-01', 22000.00, 17000.00),
(7, '2024-07-01', 25000.00, 18000.00),
(8, '2024-08-01', 26000.00, 19000.00),
(9, '2024-09-01', 27000.00, 20000.00),
(10, '2024-10-01', 28000.00, 21000.00),
(11, '2024-11-01', 29000.00, 22000.00),
(12, '2024-12-01', 30000.00, 23000.00),
(13, '2025-01-01', 31000.00, 24000.00),
(14, '2025-02-01', 32000.00, 25000.00),
(15, '2025-03-01', 33000.00, 26000.00),
(16, '2025-04-01', 34000.00, 27000.00),
(17, '2025-05-01', 35000.00, 28000.00),
(18, '2025-06-01', 36000.00, 29000.00),
(19, '2025-07-01', 37000.00, 30000.00),
(20, '2025-08-01', 38000.00, 31000.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Username` (`Username`);

--
-- Indexes for table `cart_tbl`
--
ALTER TABLE `cart_tbl`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `inventory_tbl`
--
ALTER TABLE `inventory_tbl`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `order_tbl`
--
ALTER TABLE `order_tbl`
  ADD PRIMARY KEY (`order_id2`);

--
-- Indexes for table `payment_tbl`
--
ALTER TABLE `payment_tbl`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `promotion_tbl`
--
ALTER TABLE `promotion_tbl`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `coupon_code` (`coupon_code`);

--
-- Indexes for table `sc_tbl`
--
ALTER TABLE `sc_tbl`
  ADD PRIMARY KEY (`customization_id`);

--
-- Indexes for table `total_revenue`
--
ALTER TABLE `total_revenue`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `cart_tbl`
--
ALTER TABLE `cart_tbl`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1019;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `inventory_tbl`
--
ALTER TABLE `inventory_tbl`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `order_tbl`
--
ALTER TABLE `order_tbl`
  MODIFY `order_id2` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2008;

--
-- AUTO_INCREMENT for table `payment_tbl`
--
ALTER TABLE `payment_tbl`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `promotion_tbl`
--
ALTER TABLE `promotion_tbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `sc_tbl`
--
ALTER TABLE `sc_tbl`
  MODIFY `customization_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `total_revenue`
--
ALTER TABLE `total_revenue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
