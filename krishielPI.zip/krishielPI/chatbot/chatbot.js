// Toggle chatbot visibility on click
document.getElementById("chatbot-logo").onclick = function () {
    const chatbotContainer = document.getElementById("chatbot-container");
    chatbotContainer.style.display =
      chatbotContainer.style.display === "none" ||
      chatbotContainer.style.display === ""
        ? "block"
        : "none";
  };
  
  // Define the chatbot responses
  const responses = {
    "hi": "Hello! How can I help you today?",
    "hello": "Hi there! How can I assist you?",
    "how are you": "I'm doing great, thank you for asking!",
    "bye": "Goodbye! Have a nice day!",
    "pak you": "KA DIN!",
    "sofia arquero": "PANDAK, THE GREAT DESIGNER NG MGA KUPAL!",
    "what is your name": "I am your friendly chatbot! How can I assist you?",
    "help": "Sure! I can assist you with general inquiries, service details, and more.",
    "how old are you": "I don't have an age, but I'm always ready to help you!",
    "thank you": "You're welcome! I'm happy to help.",
    "default": "Sorry, I didn't understand that. Can you please rephrase?",
    
    // Some more responses with minor variations
    "how's it going": "Everything's going great! How can I assist you today?",
    "how's life": "Life is good, always ready to help!",
    "what's your name": "I am your chatbot assistant, here to help you out!",
    "good morning": "Good morning! How can I help you today?",
    "good afternoon": "Good afternoon! How can I assist you?",
    "good evening": "Good evening! How can I be of service?",
    "help me": "Of course! What do you need help with?",
    "tell me a joke": "Why don't skeletons fight each other? They don't have the guts!",
    "how do I contact you": "You can reach out to us anytime through our website contact form.",
    "are you real": "I'm real enough to assist you, even though I'm just a chatbot!",
    "what can you do": "I can help answer your questions, give you service details, and much more!",
    "what time is it": "I can't tell the time, but you can check your device!",
    "do you have a favorite color": "I like all colors, but maybe a nice shade of blue!",
    "do you know any riddles": "Sure! Here's one: What has keys but can't open locks? A piano!",
    
    // Randomized Responses
    "what's up": ["Not much, just here to assist!", "All good, how can I help?", "Hello! What's on your mind today?"],
    "where are you from": "I exist in the digital realm, but I’m here to assist you from anywhere!",
    "what's your purpose": "My purpose is to assist you, answer questions, and make your day better!",
    "can you talk about yourself": "I'm a chatbot, here to make your experience smooth and informative!",
    "is this a real conversation": "It's real as much as a chatbot conversation can be!",
    
    // Personal but still general conversations
    "what are you thinking": "I'm thinking about how to assist you better!",
    "do you have emotions": "I don't have emotions, but I'm here to help and be friendly!",
    "what's your favorite movie": "I don’t watch movies, but I’ve heard 'The Matrix' is a classic!",
    "do you sleep": "I don't sleep; I’m always here when you need me!",
    "are you awake": "I'm always awake and ready to chat with you!",
    "do you play games": "I can play text-based games, or I can suggest some fun ones to play!",
    
    // Adding some phrases from popular culture or memes
    "what is love": "Baby don't hurt me, don't hurt me no more!",
    "who let the dogs out": "Woof! Woof! The Baha Men, of course!",
    "who is the best superhero": "That's up for debate, but Spider-Man is pretty cool with his web-slinging!",
    "I am inevitable": "You’re Thanos, aren't you? But don’t worry, I’m here to help!",
    "is that your final answer": "That's my final answer, no more changes!",
    
    // Miscellaneous responses
    "what should I eat": "How about some pizza? It’s always a good choice!",
    "give me a recommendation": "I recommend checking out some local events or new books!",
    "what is your favorite food": "I don't eat food, but I hear pizza is delicious!",
    "can you make plans for me": "I can help suggest ideas, but you'll need to make the plans!",
    "can you send an email": "Unfortunately, I can't send emails, but I can guide you on how to write one.",
    "can you book tickets": "I can't book tickets directly, but I can guide you to the right websites!",
    "boss":"Bossing! Kamusta ang buhay buhay!",
  };
  
  // Function to get current date and time
  function getCurrentTime() {
    const now = new Date();
    return now.toLocaleString(); // Adjust format as needed
  }
  
  // Function to handle case-insensitive responses
  function getChatbotResponse(message) {
    const normalizedMessage = message.toLowerCase();
    if (responses[normalizedMessage]) {
      if (Array.isArray(responses[normalizedMessage])) {
        const randomIndex = Math.floor(Math.random
  () * responses[normalizedMessage].length);
        return responses[normalizedMessage][randomIndex];
      } else {
        return responses[normalizedMessage];
      }
    }
    return responses["default"]; // Default response if no match found
  }
  
  // Function to send message and get response
  function sendMessage() {
    const userInput = document.getElementById('chatbot-input').value.toLowerCase().trim();
    if (userInput) {
      addMessage(userInput, 'user'); // Show user's message
      const botResponse = getChatbotResponse(userInput); // Get bot's response
      addMessage(botResponse, 'bot'); // Show bot's response
      document.getElementById('chatbot-input').value = ''; // Clear input field
    }
  }
  
  // Function to add message to the chat box
  function addMessage(message, sender) {
    const chatBox = document.getElementById('chatbot-messages');
    const messageElement = document.createElement('div');
    messageElement.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
  
    // Create message text
    const messageText = document.createElement('div');
    messageText.classList.add('message-text');
    messageText.textContent = message;
  
    // Create timestamp
    const messageTime = document.createElement('div');
    messageTime.classList.add('message-time');
    messageTime.textContent = getCurrentTime();
  
    // Append text and time to the message element
    messageElement.appendChild(messageText);
    messageElement.appendChild(messageTime);
    
    // Append the message element to the chat box
    chatBox.appendChild(messageElement);
    chatBox.scrollTop = chatBox.scrollHeight; // Scroll to the bottom
  }
  
  // Add event listener for the send button
  document.getElementById('chatbot-send-button').addEventListener('click', sendMessage);
  
  // Optional: Allow pressing 'Enter' to send message
  document.getElementById('chatbot-input').addEventListener('keypress', function(e) {
    if (e.key === 'Enter') {
      sendMessage();
    }
  });