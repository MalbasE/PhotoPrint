<?php
// Include the database connection file
$host = "localhost";
$username = "root";
$password = "";
$dbname = "kpis";

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the data
$sql = "SELECT MONTH(date) AS month, SUM(total_P) AS total_P, SUM(total_R) AS total_R FROM total_revenue GROUP BY MONTH(date)";
$result = $conn->query($sql);

$months = [];
$total_P = [];
$total_R = [];

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $months[] = date("F", mktime(0, 0, 0, $row['month'], 1)); // Convert month number to name
        $total_P[] = $row['total_P'];
        $total_R[] = $row['total_R'];
    }
}

// Close the connection
$conn->close();

// Pass data to JavaScript
echo "<script>
    var chartMonths = " . json_encode($months) . ";
    var chartTotalP = " . json_encode($total_P) . ";
    var chartTotalR = " . json_encode($total_R) . ";
    var chartType = 'bar'; // Start with 'bar' chart type
</script>";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <title>Admin Dashboard</title>
    <style>
        /* Reset and Basic Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 20%;
            background: linear-gradient(to bottom, #f8d8ff, #fefbbf);
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .profile {
            text-align: center;
        }

        .profile-icon img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: pink;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .profile p {
            margin-top: 10px;
            font-weight: bold;
            font-size: 18px;
            color: #555;
        }

        .menu {
            list-style: none;
            width: 100%;
            padding: 0;
        }

        .menu li {
            margin: 15px 0;
            text-align: left;
        }

        .menu li a {
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 15px;
            color: #555;
            background: #fff;
            transition: background 0.3s, color 0.3s;
        }

        .menu li a img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #f5f5f5;
            padding: 5px;
        }

        .menu li a:hover {
            background: #fefbbf;
            color: #f55;
        }

        /* Header Styling */
        .header {
            width: 80%;
            background: #fefefe;
            display: flex;
            flex-direction: column;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Combined Welcome and Search Section */
        .welcome-search-container {
            padding: 25px;
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            margin-left: -20px;
            margin-right: -20px;
            border-radius: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100px;
            margin-top: -20px;
        }

        .welcome-section h1 {
            color: #d15;
            font-size: 30px;
            letter-spacing: 1px;
            margin: 0;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-bar input {
            padding: 12px 25px;
            border: 2px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 16px;
        }

        .search-bar button {
            padding: 10px 14px;
            border: none;
            border-radius: 50%;
            background: #ff7a7a;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Chart Container */
        .chart-container {
            margin-top: 20px;
            padding: 20px;
            background: #fff;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
        }

        #myChart {
            max-width: 100%;
        }

        .toggle-button {
            margin-top: 15px;
            padding: 10px 20px;
            background: #00c8ff;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .toggle-button:hover {
            background: #0088cc;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="profile">
            <div class="profile-icon">
                <img src="../images/adminlogo.png" alt="Admin Logo">
            </div>
            <p>ADMINISTRATOR</p>
        </div>
        <ul class="menu">
            <li><a href="adminDash.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="admin_order.php"><i class="fas fa-box"></i> Orders</a></li>
            <li><a href="admin_inventory.php"><i class="fas fa-cogs"></i> Inventory</a></li>
            <li><a href="admin_service.php"><i class="fas fa-cogs"></i> Services Customization</a></li>
            <li><a href="admin_payment.php"><i class="fas fa-credit-card"></i> Payment Tracking</a></li>
            <li><a href="admin_promotion.php"><i class="fas fa-bullhorn"></i> Promotion</a></li>
            <li><a href="admin_delivery.php"><i class="fas fa-truck"></i> Delivery</a></li>
            <li><a href="admin_user_account.php"><i class="fas fa-user-cog"></i> User Account Management</a></li>
            <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    <div class="header">
        <div class="welcome-search-container">
            <div class="welcome-section">
                <h1>WELCOME ADMIN!</h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search">
                <button>🔍</button>
            </div>
        </div>
        <div class="chart-container">
            <button class="toggle-button" onclick="toggleChartType()">TOGGLE INFO</button>
            <canvas id="myChart"></canvas>
        </div>
    </div>

    <script>
        // Wait until the document is fully loaded before creating the chart
        let ctx = document.getElementById('myChart').getContext('2d');

        // Function to initialize the chart with the correct type
        function createChart(type) {
            new Chart(ctx, {
                type: type, // chart type is dynamic based on button click
                data: {
                    labels: chartMonths,
                    datasets: [{
                        label: 'Total P',
                        data: chartTotalP, // Data passed from PHP
                        backgroundColor: 'rgba(255, 99, 132, 0.2)',
                        borderColor: 'rgba(255, 99, 132, 1)',
                        borderWidth: 1,
                        // Set this dataset as a bar chart
                        type: type === 'bar' ? 'bar' : 'line',
                        fill: false,
                    }, {
                        label: 'Total R',
                        data: chartTotalR, // Data passed from PHP
                        backgroundColor: 'rgba(153, 102, 255, 0.2)',
                        borderColor: 'rgba(153, 102, 255, 1)',
                        borderWidth: 1,
                        // Set this dataset as a bar chart
                        type: type === 'bar' ? 'bar' : 'line',
                        fill: false,
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Monthly Total P and R'
                        }
                    }
                }
            });
        }

        // Toggle between bar and line chart
        function toggleChartType() {
            chartType = (chartType === 'bar') ? 'line' : 'bar'; // Toggle chart type
            createChart(chartType); // Redraw the chart with the new type
        }

        // Initial chart rendering
        createChart(chartType);
    </script>
</body>
</html>
