<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <title>Admin Delivery</title>
    <style>
        /* Reset and Basic Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 20%;
            background: linear-gradient(to bottom, #f8d8ff, #fefbbf);
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .profile {
            text-align: center;
        }

        .profile-icon img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: pink;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .profile p {
            margin-top: 10px;
            font-weight: bold;
            font-size: 18px;
            color: #555;
        }

        .menu {
            list-style: none;
            width: 100%;
            padding: 0;
        }

        .menu li {
            margin: 15px 0;
            text-align: left;
        }

        .menu li a {
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 15px;
            color: black;
            background: #fff;
            transition: background-color 0.3s, color 0.3s;
        }

        .menu li a img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #f5f5f5;
            padding: 5px;
        }

        .menu li a:hover {
            background-color: rgb(223, 55, 83);
            color: white;
        }

        /* Header Styling */
        .header {
            width: 80%;
            background: #fefefe;
            display: flex;
            flex-direction: column;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Combined Welcome and Search Section */
        .welcome-search-container {
            padding: 25px; /* Increased padding */
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            margin-left: -20px;
            margin-right: -20px;
            border-radius: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100px; /* Adjusted height for more space */
            margin-top: -20px;
             /* Shift the container upwards */
        }

        .welcome-section h1 {
            color: #d15;
            font-size: 30px; /* Increased font size for emphasis */
            letter-spacing: 1px;
            margin: 0;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-bar input {
            padding: 12px 25px; /* Adjust padding for larger input field */
            border: 2px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 16px; /* Adjust font size for better readability */
        }

        .search-bar button {
            padding: 10px 14px;
            border: none;
            border-radius: 50%;
            background: #ff7a7a;
            color: #fff;
            font-size: 18px; /* Increased button icon size */
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .approval-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.approval-table th, .approval-table td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
}

.approval-table th {
    background-color: #f4f4f4;
}

.approval-table td a {
    color: #4CAF50;
    text-decoration: none;
}

.approval-table td a:hover {
    text-decoration: underline;
}
.section-heading{
    margin-top:20px;
}
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="profile">
    <div class="profile-icon">

        <img src="../images/adminlogo.png" alt="Admin Logo" width="80" height="80">
    </div>
    <p>ADMINISTRATOR</p>
</div>
<ul class="menu">
            <li><a href="adminDash.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="admin_order.php"><i class="fas fa-box"></i> Orders</a></li>
            <li><a href="admin_inventory.php"><i class="fas fa-cogs"></i> Inventory</a></li>
            <li><a href="admin_service.php"><i class="fas fa-cogs"></i> Services Customization</a></li>
            <li><a href="admin_payment.php"><i class="fas fa-credit-card"></i> Payment Tracking</a></li>
            <li><a href="admin_promotion.php"><i class="fas fa-bullhorn"></i> Promotion</a></li>
            <li><a href="admin_delivery.php"><i class="fas fa-truck"></i> Delivery</a></li>
            <li><a href="admin_user_account.php"><i class="fas fa-user-cog"></i> User Account Management</a></li>
            <li><a href="#" onclick="confirmLogout(); return false;"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    <div class="header">
        <!-- Combined Section -->
        <div class="welcome-search-container">
            <div class="welcome-section">
                <h1>WELCOME ADMIN!</h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search">
                <button>🔍</button>
            </div>
        </div>
        <!--Start ot content-->
     
<main class="content">
    <header class="section-header">
        <h2 class="section-heading">Delivery Lists</h2>
    </header>

    <table class="approval-table">
        <thead>
            <tr>
                <th>Delivery ID</th>
                <th>Order ID</th>
                <th>Customer Name</th>
                <th>Service Type</th>
                <th>Price</th>
                <th>Delivery Status</th>
                <th>Delivery Date</th>
                <th>Tracking Number</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Ensure $orders is an array and contains elements before using foreach
            if (isset($orders) && is_array($orders) && count($orders) > 0) {
                foreach ($orders as $order) {
                    echo "<tr>
                        <td>{$order['delivery_id']}</td>
                        <td>{$order['order_id']}</td>
                        <td>{$order['customer_name']}</td>
                        <td>{$order['service_type']}</td>
                        <td>" . number_format($order['price'], 2) . "</td>
                        <td>{$order['delivery_status']}</td>
                        <td>" . ($order['delivery_date'] ? htmlspecialchars($order['delivery_date']) : 'Not Set') . "</td>
                        <td>" . ($order['tracking_number'] ? htmlspecialchars($order['tracking_number']) : 'Not Set') . "</td>
                        <td>
                            <a href='admin_delivery.php?approve_id={$order['delivery_id']}'>Approve</a> | 
                            <a href='admin_delivery.php?view_id={$order['delivery_id']}'>View</a>
                        </td>
                    </tr>";
                }
            } else {
                // If no records found or query failed, display a message
                echo "<tr><td colspan='9'>No records found.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</main>
<!-- End of Code of Content -->
<script>
        function confirmLogout() {
            // Display confirmation message
            var confirmation = confirm("Are you sure you want to log out?");
            
            // Check user response
            if (confirmation) {
                alert("You have successfully logged out.");
                // Redirect to the logout or login page
                window.location.href = "admin_login.php";
            } else {
                alert("Logout cancelled.");
            }
        }
</script>

</body>
</html>
