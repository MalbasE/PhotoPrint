<?php
session_start();  // Start session to store login status

// Include database connection
include('../included/db_conn.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Sanitize the inputs to prevent SQL Injection
    $username = $conn->real_escape_string($username);
    $password = $conn->real_escape_string($password);

    // Query to check if the admin exists
    $sql = "SELECT * FROM admin_tbl WHERE Username = '$username' AND Password = '$password'";
    $result = $conn->query($sql);

    // Check if user exists
    if ($result->num_rows > 0) {
        // Admin found, log in
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;

        // Redirect to the admin dashboard or another page
        header("Location: adminDash.php");
        exit;
    } else {
        // Invalid login credentials
        echo "<script>alert('Invalid username or password');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Admin Login</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background-image: url('background.jpg');
      background-size: cover;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .container {
      background-color: rgba(255, 255, 255, 0.8);
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      text-align: center;
    }

    .logo {
      margin-bottom: 20px;
    }

    .logo img {
      width: 100px;
      height: 100px;
      border-radius: 50%;
    }

    .logo p {
      font-size: 24px;
      font-weight: bold;
      margin-top: 10px;
    }

    .login-form {
      margin-top: 20px;
    }

    .login-form input {
      width: 100%;
      padding: 10px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }

    .login-form button {
      width: 100%;
      padding: 10px;
      background-color: #F08080;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="logo">
    <img src="../images/logo.png" alt="Logo"> <p>KRISHIEL</p>
  </div>
  <div class="container">
    <div class="login-form">
      <h2>ADMIN</h2>
      <form  method="post">
        <input type="text" name="username" placeholder="USERNAME" required>
        <input type="password" name="password" placeholder="PASSWORD" required>
        <button type="submit">LOGIN</button>
      </form>
    </div>
  </div>
</body>
</html>
