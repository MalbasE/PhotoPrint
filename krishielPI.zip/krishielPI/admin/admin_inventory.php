<?php
// Include the database connection
include('../included/db_conn.php'); // Include your DB connection script

// Fetch the inventory items from the database
$sql = "SELECT * FROM inventory_tbl"; // Query to get all items in the inventory
$items = []; // Initialize the items variable as an empty array

if ($result = $conn->query($sql)) {
    // Fetch all inventory records and store them in $items
    $items = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $error = "Error fetching items: " . $conn->error; // Handle query failure
}

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Sanitize and validate form inputs
    $item_name = isset($_POST['item_name']) ? trim($_POST['item_name']) : '';
    $quantity = isset($_POST['quantity']) ? (int) $_POST['quantity'] : 0;

    // Basic validation: Check if item name and quantity are not empty
    if (empty($item_name) || $quantity <= 0) {
        $error = "Please fill in all fields correctly.";
    } else {
        // Prepare an insert query to add the item to the database
        $sql = "INSERT INTO inventory_tbl(item_name, quantity, created_at) VALUES (?, ?, NOW())";

        if ($stmt = $conn->prepare($sql)) {
            // Bind the parameters
            $stmt->bind_param("si", $item_name, $quantity);

            // Execute the query
            if ($stmt->execute()) {
                // Redirect to avoid form resubmission on refresh
                header("Location: admin_inventory.php");
                exit();
            } else {
                $error = "Error adding item: " . $stmt->error;
            }

            // Close the statement
            $stmt->close();
        } else {
            $error = "Error preparing query: " . $conn->error;
        }
    }
}
// Edit the Inventory
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['item_id'])) {
    $item_id = $_POST['item_id'];
    $item_name = $_POST['item_name'];
    $quantity = $_POST['quantity'];

    // Update the database with the new data
    $sql = "UPDATE items SET item_name = ?, quantity = ? WHERE item_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $item_name, $quantity, $item_id);
    $stmt->execute();
    
    // Redirect or show success message
    header("Location: admin_inventory.php");
}
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if 'item_id' is provided in the query string
if (isset($_GET['item_id'])) {
    $item_id = intval($_GET['item_id']); // Ensure it's an integer

    // SQL query to delete the record
    $sql = "DELETE FROM inventory_tbl WHERE item_id = ?";
    
    // Prepare and execute the query
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $item_id);

    if ($stmt->execute()) {
        // Use JavaScript alert for success message
        echo "<script>alert('Record deleted successfully.');</script>";
    } else {
        // Use JavaScript alert for error message
        echo "<script>alert('Error deleting record: " . $conn->error . "');</script>";
    }

    // Close the statement
    $stmt->close();
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    
    <title>Admin Inventory</title>
    <style>
        /* Reset and Basic Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 20%;
            background: linear-gradient(to bottom, #f8d8ff, #fefbbf);
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .profile {
            text-align: center;
        }

        .profile-icon img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: pink;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .profile p {
            margin-top: 10px;
            font-weight: bold;
            font-size: 18px;
            color: #555;
        }

        .menu {
            list-style: none;
            width: 100%;
            padding: 0;
        }

        .menu li {
            margin: 15px 0;
            text-align: left;
        }

        .menu li a {
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 15px;
            color: black;
            background: #fff;
            transition: background-color 0.3s, color 0.3s;
        }

        .menu li a img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #f5f5f5;
            padding: 5px;
        }

        .menu li a:hover {
            background-color: rgb(223, 55, 83);
            color: white;
        }

        /* Header Styling */
        .header {
            width: 80%;
            background: #fefefe;
            display: flex;
            flex-direction: column;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Combined Welcome and Search Section */
        .welcome-search-container {
            padding: 25px; /* Increased padding */
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            margin-left: -20px;
            margin-right: -20px;
            border-radius: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100px; /* Adjusted height for more space */
            margin-top: -20px;
             /* Shift the container upwards */
        }

        .welcome-section h1 {
            color: #d15;
            font-size: 30px; /* Increased font size for emphasis */
            letter-spacing: 1px;
            margin: 0;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-bar input {
            padding: 12px 25px; /* Adjust padding for larger input field */
            border: 2px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 16px; /* Adjust font size for better readability */
        }

        .search-bar button {
            padding: 10px 14px;
            border: none;
            border-radius: 50%;
            background: #ff7a7a;
            color: #fff;
            font-size: 18px; /* Increased button icon size */
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .approval-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
}

.approval-table th, .approval-table td {
    padding: 12px;
    text-align: left;
    border: 1px solid #ddd;
}

.approval-table th {
    background-color: #f4f4f4;
}

.approval-table td a {
    color: #4CAF50;
    text-decoration: none;
}

.approval-table td a:hover {
    text-decoration: underline;
}
.section-heading{
    margin-top:20px;
}
.add-inventory-container {
        text-align: right;
        margin-bottom: 30px;
    }

    .add-inventory-btn {
        padding: 10px 20px;
        margin: 20px auto 0;
        background-color: #ff7a7a; /* Green color */
        color: white;
        text-decoration: none;
        border-radius: 5px;
        transition: background-color 0.3s ease;
    }

    .add-inventory-btn:hover {
        background-color: #f55;
    }
    /* Modal Styling */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

.modal-content {
    background-color: #fefefe;
    margin: 15% auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
    max-width: 400px;
}

.close {
    color: #aaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: black;
    text-decoration: none;
    cursor: pointer;
}

.form-group {
    margin-bottom: 15px;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
}

.form-group input {
    width: 100%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

/* Center the button horizontally */
.btn {
    background-color: #4CAF50; /* Green */
    color: white;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    display: block; /* Make the button a block-level element */
    margin: 20px auto 0 auto; /* Center horizontally */
}

.btn:hover {
    background-color: #45a049;
}
label[for="item_name"] {
    margin-top: 20px; 
}
#item_name {
    width: 100%; /* Make the dropdown take up the full width */
    padding: 10px; /* Add padding for better spacing */
    font-size: 16px; /* Increase font size for better readability */
    border: 1px solid #ccc; /* Light border color */
    border-radius: 4px; /* Slightly rounded corners */
    background-color: #f9f9f9; /* Light background color */
    cursor: pointer; /* Change cursor to pointer for better UX */
    text-align: center; /* Center the text inside the select element */
    position: relative; /* Set relative positioning */
}

/* Style the options inside the select dropdown */
#item_name option {
    padding: 10px; /* Add padding to options for better spacing */
    font-size: 16px; /* Increase font size of options */
    text-align: center; /* Center the text inside the option */
    background-color: #f9f9f9; /* Background color for the options */
}

/* Optional: Style the select when it’s focused */
#item_name:focus {
    border-color: #4CAF50; /* Change border color when focused */
    outline: none; /* Remove default focus outline */
}

input, select {
    width: 100%; /* Full width for input and select */
    padding: 10px; /* Add padding for better readability */
    font-size: 16px; /* Font size for inputs and selects */
    margin-top: 5px; /* Space above the input/select */
}

    </style>
</head>
<body>
    <div class="sidebar">
        <div class="profile">
    <div class="profile-icon">

        <img src="../images/adminlogo.png" alt="Admin Logo" width="80" height="80">
    </div>
    <p>ADMINISTRATOR</p>
</div>
        <ul class="menu">
            <li><a href="adminDash.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="admin_order.php"><i class="fas fa-box"></i> Orders</a></li>
            <li><a href="admin_inventory.php"><i class="fas fa-cogs"></i> Inventory</a></li>
            <li><a href="admin_service.php"><i class="fas fa-cogs"></i> Services Customization</a></li>
            <li><a href="admin_payment.php"><i class="fas fa-credit-card"></i> Payment Tracking</a></li>
            <li><a href="admin_promotion.php"><i class="fas fa-bullhorn"></i> Promotion</a></li>
            <li><a href="admin_delivery.php"><i class="fas fa-truck"></i> Delivery</a></li>
            <li><a href="admin_user_account.php"><i class="fas fa-user-cog"></i> User Account Management</a></li>
            <li><a href="#" onclick="confirmLogout(); return false;"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    <div class="header">
        <!-- Combined Section -->
        <div class="welcome-search-container">
            <div class="welcome-section">
                <h1>WELCOME ADMIN!</h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search">
                <button>🔍</button>
            </div>
        </div>
        <!--Start ot content-->
        
        <main class="content">
    <header class="section-header">
        <h2 class="section-heading">Inventory</h2>
    </header>
    <div class="add-inventory-container">
        <a href="javascript:void(0);" id="openModal" class="add-inventory-btn">Add Inventory</a>
    </div>
    
    <!-- Modal for adding inventory -->
    <div id="inventoryModal" class="modal">
    <div class="modal-content">
        <span class="close" id="closeInventoryModal">&times;</span>
        <h2>Add Inventory Item</h2>
        <form action="admin_inventory.php" method="POST" id="addInventoryForm">
            <div class="form-group">
                <label for="item_name">Item Name:</label>
                <select id="item_name" name="item_name" required>
                    <option value="">-- Select Item --</option>
                    <!-- Printing Items -->
                    <option value="Bond Paper">Bond Paper</option>
                    <option value="Photo Paper">Photo Paper</option>
                    <option value="Colored Paper">Colored Paper</option>
                    <option value="Card Stock">Card Stock</option>
                    <option value="Transparency Film">Transparency Film</option>

                    <!-- Ink and Toner -->
                    <option value="Ink Cartridge">Ink Cartridge</option>
                    <option value="Toner Cartridge">Toner Cartridge</option>
                    <option value="Printer Ribbon">Printer Ribbon</option>
                    <option value="Refill Ink">Refill Ink</option>

                    <!-- Laminating Items -->
                    <option value="Laminating Film">Laminating Film</option>
                    <option value="Laminating Pouches">Laminating Pouches</option>
                    <option value="Laminating Rolls">Laminating Rolls</option>

                    <!-- Imaging Items -->
                    <option value="Photo Ink">Photo Ink</option>
                    <option value="Photo Frames">Photo Frames</option>
                    <option value="Canvas Sheets">Canvas Sheets</option>
                    <option value="Imaging Paper">Imaging Paper</option>
                </select>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" required min="1">
            </div>
            <button type="submit" class="btn">Add Item</button>
        </form>
    </div>
</div>


 <!-- Table displaying the items -->
<table class="approval-table">
    <thead>
        <tr>
            <th>#</th>
            <th>Item Name</th>
            <th>Quantity</th>
            <th>Recorded Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        // Row counter
        $counter = 1;

        // Loop through each item record and display it in the table
        foreach ($items as $item) {
            echo "<tr>
                <td>{$counter}</td>
                <td>{$item['item_name']}</td>
                <td>{$item['quantity']}</td>
                <td>{$item['created_at']}</td>
                <td>
                    <a href='javascript:void(0);' class='edit-btn' 
                       data-id='{$item['item_id']}' 
                       data-name='{$item['item_name']}' 
                       data-quantity='{$item['quantity']}'>Edit</a> |   
                <a href='admin_inventory.php?item_id={$item['item_id']}' 
        class='delete-btn' 
        onclick=\"return confirm('Are you sure you want to delete this item from the inventory?');\">
        Delete
      </a>
                </td>
            </tr>";
            $counter++; // Increment the row counter
        }
        ?>
    </tbody>
</table>


   <!-- Modal for editing item details -->
   <div id="editModal" class="modal">
       <div class="modal-content">
           <span class="close" id="closeEditModal">&times;</span>
           <h2>Edit Inventory Item</h2>
           <form action="admin_inventory.php" method="POST" id="editItemForm">
               <input type="hidden" id="item_id" name="item_id"> <!-- Hidden input for item ID -->
               <div class="form-group">
                   <label for="edit_item_name">Item Name:</label>
                   <input type="text" id="edit_item_name" name="item_name" required>
               </div>
               <div class="form-group">
                   <label for="edit_quantity">Quantity:</label>
                   <input type="number" id="edit_quantity" name="quantity" required min="1">
               </div>
               <button type="submit" class="btn">Save Changes</button>
           </form>
       </div>
   </div>
</main>

<script>
    // Handle "Add Inventory" Modal
    var inventoryModal = document.getElementById("inventoryModal");
    var openInventoryModalBtn = document.getElementById("openModal");
    var closeInventoryModalBtn = document.getElementById("closeInventoryModal");

    // Open the inventory modal
    openInventoryModalBtn.onclick = function() {
        inventoryModal.style.display = "block";
    }

    // Close the inventory modal (by clicking the "X")
    closeInventoryModalBtn.onclick = function() {
        inventoryModal.style.display = "none";
    }

    // Close the inventory modal when clicking outside of it
    window.addEventListener("click", function(event) {
        if (event.target === inventoryModal) {
            inventoryModal.style.display = "none";
        }
    });

    // Handle "Edit Inventory" Modal
    var editModal = document.getElementById("editModal");
    var closeEditModalBtn = document.getElementById("closeEditModal");

    // Get all the edit buttons
    var editButtons = document.querySelectorAll('.edit-btn');

    // Add event listener to each edit button
    editButtons.forEach(function(btn) {
        btn.onclick = function() {
            // Get data attributes of the clicked edit button
            var itemId = this.getAttribute('data-id');
            var itemName = this.getAttribute('data-name');
            var quantity = this.getAttribute('data-quantity');
            
            // Set the values in the modal's input fields
            document.getElementById('item_id').value = itemId;
            document.getElementById('edit_item_name').value = itemName;
            document.getElementById('edit_quantity').value = quantity;
            
            // Show the modal
            editModal.style.display = "block";
        };
    });

    // Close the edit modal (by clicking the "X")
    closeEditModalBtn.onclick = function() {
        editModal.style.display = "none";
    }

    // Close the edit modal when clicking outside of it
    window.addEventListener("click", function(event) {
        if (event.target === editModal) {
            editModal.style.display = "none";
        }
    });
</script>
<script>
        function confirmLogout() {
            // Display confirmation message
            var confirmation = confirm("Are you sure you want to log out?");
            
            // Check user response
            if (confirmation) {
                alert("You have successfully logged out.");
                // Redirect to the logout or login page
                window.location.href = "admin_login.php";
            } else {
                alert("Logout cancelled.");
            }
        }
</script>


</body>
</html>
