<?php
// Include database connection
include('../included/db_conn.php');

// Handle Add User
if (isset($_POST['submit_add'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);

    $query = "INSERT INTO customers (customer_name, email, gender, date_of_birth, phone_number, address) 
              VALUES ('$name', '$email', '$gender', '$dob', '$phone', '$address')";

    if ($conn->query($query)) {
        echo "<script>alert('New user added successfully!'); window.location.href = 'admin_user_account.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Handle Edit User
if (isset($_POST['submit_edit'])) {
    $user_id = $conn->real_escape_string($_POST['user_id']);
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $gender = $conn->real_escape_string($_POST['gender']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);

    $query = "UPDATE customers SET 
                customer_name = '$name', 
                email = '$email', 
                gender = '$gender', 
                date_of_birth = '$dob', 
                phone_number = '$phone', 
                address = '$address' 
              WHERE user_id = '$user_id'";

    if ($conn->query($query)) {
        echo "<script>alert('User updated successfully!'); window.location.href = 'admin_user_account.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Handle Delete User
if (isset($_POST['delete_user'])) {
    $user_id = $conn->real_escape_string($_POST['user_id']);

    $query = "DELETE FROM customers WHERE user_id = '$user_id'";

    if ($conn->query($query)) {
        echo "<script>alert('User deleted successfully!'); window.location.href = 'admin_user_account.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}

// Fetch user data to display
$query = "SELECT * FROM customers";
$result = $conn->query($query);

if (!$result) {
    die("Error fetching data: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin User Account</title>
    <style>
        /* Reset and Basic Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 20%;
            background: linear-gradient(to bottom, #f8d8ff, #fefbbf);
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .profile {
            text-align: center;
        }

        .profile-icon img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: pink;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .profile p {
            margin-top: 10px;
            font-weight: bold;
            font-size: 18px;
            color: #555;
        }

        .menu {
            list-style: none;
            width: 100%;
            padding: 0;
        }

        .menu li {
            margin: 15px 0;
            text-align: left;
        }

        .menu li a {
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 15px;
            color: #555;
            background: #fff;
            transition: background 0.3s, color 0.3s;
        }

        .menu li a img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #f5f5f5;
            padding: 5px;
        }

        .menu li a:hover {
            background: #fefbbf;
            color: #f55;
        }

        /* Header Styling */
        .header {
            width: 80%;
            background: #fefefe;
            display: flex;
            flex-direction: column;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Combined Welcome and Search Section */
        .welcome-search-container {
            padding: 25px;
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            margin-left: -20px;
            margin-right: -20px;
            border-radius: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100px;
            margin-top: -20px;
        }

        .welcome-section h1 {
            color: #d15;
            font-size: 30px;
            letter-spacing: 1px;
            margin: 0;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-bar input {
            padding: 12px 25px;
            border: 2px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 16px;
        }

        .search-bar button {
            padding: 10px 14px;
            border: none;
            border-radius: 50%;
            background: #ff7a7a;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* User Accounts Styling */
        .user-accounts {
            margin-top: 20px;
        }

        .user-accounts table {
            width: 100%;
            border-collapse: collapse;
            margin-top:30px;
        }

        .user-accounts table th, .user-accounts table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .user-accounts button {
            background-color: #f55;
            color: white;
            border: none;
            padding: 8px 15px;
            cursor: pointer;
            border-radius: 5px;
           
        }

        .user-accounts button:hover {
            background-color: #d44;
        }

        /* Modal Styling */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
        }

        .modal-content {
            background-color: #fff;
            margin: 15% auto;
            padding: 20px;
            border-radius: 5px;
            width: 50%;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }
        .add-user-button {
            position: absolute;
            top: 120px;
            right: 20px;
            background-color: #ff7a7a;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .add-user-button:hover {
            background-color: #d44;
        }
        /* General Modal Styles */
.modal {
    display: none;
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.4);
}

.modal-content {
    background-color: #fff;
    margin: 10% auto;
    padding: 20px;
    border-radius: 5px;
    width: 50%;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

.modal-content label {
    display: block;
    margin-top: 10px;
}

.modal-content input,
.modal-content button {
    width: 100%;
    margin-top: 5px;
    padding: 10px;
    font-size: 16px;
}

.close {
    float: right;
    font-size: 28px;
    font-weight: bold;
    cursor: pointer;
}

.close:hover {
    color: red;
}
.save-changes-button {
        background-color: #ff7a7a; /* Green color */
        color: white; /* White text */
        font-weight: bold;
        border: #ff7a7a;
    }

    .save-changes-button:hover {
        background-color:rgb(233, 23, 23); /* Darker green on hover */
    }
    .Add-button {
        background-color: #ff7a7a; /* Green color */
        color: white; /* White text */
        font-weight: bold;
        border: #ff7a7a;
    }

    .Add-button:hover {
        background-color:rgb(233, 23, 23); /* Darker green on hover */
    }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="profile">
            <div class="profile-icon">
                <img src="../images/adminlogo.png" alt="Admin Logo" width="80" height="80">
            </div>
            <p>ADMINISTRATOR</p>
        </div>
        <ul class="menu">
            <li><a href="adminDash.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="admin_order.php"><i class="fas fa-box"></i> Orders</a></li>
            <li><a href="admin_inventory.php"><i class="fas fa-cogs"></i> Inventory</a></li>
            <li><a href="admin_service.php"><i class="fas fa-cogs"></i> Services Customization</a></li>
            <li><a href="admin_payment.php"><i class="fas fa-credit-card"></i> Payment Tracking</a></li>
            <li><a href="admin_promotion.php"><i class="fas fa-bullhorn"></i> Promotion</a></li>
            <li><a href="admin_delivery.php"><i class="fas fa-truck"></i> Delivery</a></li>
            <li><a href="admin_user_account.php"><i class="fas fa-user-cog"></i> User Account Management</a></li>
            <li><a href="#"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <div class="header">
        <div class="welcome-search-container">
            <div class="welcome-section">
                <h1>WELCOME ADMIN!</h1>
            </div>
        </div>

     
           
        <div class="user-accounts">
        <h2>User Accounts</h2>
        <button class="add-user-button" onclick="openAddModal()">Add New User</button>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Gender</th>
                        <th>DoB</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['user_id']; ?></td>
                        <td><?php echo $row['customer_name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['gender']; ?></td>
                        <td><?php echo $row['date_of_birth']; ?></td>
                        <td><?php echo $row['phone_number']; ?></td>
                        <td><?php echo $row['address']; ?></td>
                        <td>
                            <button onclick="openEditModal(<?php echo $row['user_id']; ?>, '<?php echo $row['customer_name']; ?>', '<?php echo $row['email']; ?>', '<?php echo $row['gender']; ?>', '<?php echo $row['date_of_birth']; ?>', '<?php echo $row['phone_number']; ?>', '<?php echo $row['address']; ?>')">Edit</button>
                            <form method="POST" style="display:inline-block;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                <input type="hidden" name="user_id" value="<?php echo $row['user_id']; ?>">
                                <button type="submit" name="delete_user">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal('addModal')">&times;</span>
            <form method="POST">
                <label>Name</label>
                <input type="text" name="name" required><br>
                <label>Email</label>
                <input type="email" name="email" required><br>
                <label>Gender</label>
                <input type="text" name="gender" required><br>
                <label>Date of Birth</label>
                <input type="date" name="dob" required><br>
                <label>Phone</label>
                <input type="text" name="phone" required><br>
                <label>Address</label>
                <input type="text" name="address" required><br>
                <button type="submit" name="submit_add" class="Add-button">Add User</button>
            </form>
        </div>
    </div>
    <div id="editModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal('editModal')">&times;</span>
        <form method="POST">
            <input type="hidden" name="user_id" id="edit_user_id">
            <label>Name</label>
            <input type="text" name="name" id="edit_name" required><br>
            <label>Email</label>
            <input type="email" name="email" id="edit_email" required><br>
            <label>Gender</label>
            <input type="text" name="gender" id="edit_gender" required><br>
            <label>Date of Birth</label>
            <input type="date" name="dob" id="edit_dob" required><br>
            <label>Phone</label>
            <input type="text" name="phone" id="edit_phone" required><br>
            <label>Address</label>
            <input type="text" name="address" id="edit_address" required><br>
            <button type="submit" name="submit_edit" class="save-changes-button">Save Changes</button>
        </form>
    </div>
</div>

    <script>
        function openAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }

        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }

        function openEditModal(id, name, email, gender, dob, phone, address) {
            // Populate and open edit modal logic
        }
        function openEditModal(id, name, email, gender, dob, phone, address) {
    // Populate modal fields
    document.getElementById('edit_user_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_email').value = email;
    document.getElementById('edit_gender').value = gender;
    document.getElementById('edit_dob').value = dob;
    document.getElementById('edit_phone').value = phone;
    document.getElementById('edit_address').value = address;

    // Display the modal
    document.getElementById('editModal').style.display = 'block';
}

    </script>
</body>