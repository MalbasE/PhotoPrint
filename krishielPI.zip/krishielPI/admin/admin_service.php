<?php
session_start();
include('../included/db_conn.php');

// Fetch all services from sc_tbl
$sql = "SELECT * FROM sc_tbl";
$result = $conn->query($sql);

// Check if there are any services
$services = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
}

// Handle adding a new service
if (isset($_POST['add_service'])) {
    $service_type = $_POST['service_type'];
    $customization_name = $_POST['customization_name'];
    $customization_description = $_POST['customization_description'];
    $price = $_POST['price'];

    $insert_sql = "INSERT INTO sc_tbl (service_type, customization_name, customization_description, price) 
                   VALUES ('$service_type', '$customization_name', '$customization_description', '$price')";
    if ($conn->query($insert_sql) === TRUE) {
        echo "<script>alert('Service added successfully'); window.location.href='admin_service.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
// Check if the update service form has been submitted
if (isset($_POST['update_service'])) {
    // Get the form data from POST
    $customization_id = $_POST['customization_id'];
    $service_type = $_POST['service_type'];
    $customization_name = $_POST['customization_name'];
    $customization_description = $_POST['customization_description'];
    $price = $_POST['price'];

    // Validate the form inputs (basic validation)
    if (empty($customization_id) || empty($service_type) || empty($customization_name) || empty($customization_description) || empty($price)) {
        echo "All fields are required.";
    } else {
        // Prepare the SQL UPDATE statement to update the service in the database
        $query = "UPDATE sc_tbl SET service_type = ?, customization_name = ?, customization_description = ?, price = ? WHERE customization_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("sssdi", $service_type, $customization_name, $customization_description, $price, $customization_id);
        
        // Execute the update
        if ($stmt->execute()) {
            // Redirect back to the service page after the update
            header("Location: admin_service.php");
            exit();
        } else {
            echo "Error updating service: " . $stmt->error;
        }

        $stmt->close();
    }
}

// Fetch the services data to display in the table
$services = [];
$query = "SELECT * FROM sc_tbl";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $services[] = $row;
    }
} else {
    echo "No services found.";
}

// Handle deleting a service
if (isset($_GET['delete_id'])) {
    $customization_id = $_GET['delete_id'];
    $delete_sql = "DELETE FROM sc_tbl WHERE customization_id = $customization_id";
    if ($conn->query($delete_sql) === TRUE) {
        echo "<script>alert('Service deleted successfully'); window.location.href='admin_service.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Admin Services Customization</title>
    <style>
        /* Basic Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            min-height: 100vh;
            background-color: #f8f8f8;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 20%;
            background: linear-gradient(to bottom, #f8d8ff, #fefbbf);
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .profile {
            text-align: center;
        }

        .profile-icon img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: pink;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .profile p {
            margin-top: 10px;
            font-weight: bold;
            font-size: 18px;
            color: #555;
        }

        .menu {
            list-style: none;
            width: 100%;
            padding: 0;
        }

        .menu li {
            margin: 15px 0;
            text-align: left;
        }

        .menu li a {
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 15px;
            color: black;
            background: #fff;
            transition: background-color 0.3s, color 0.3s;
        }

        .menu li a img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #f5f5f5;
            padding: 5px;
        }

        .menu li a:hover {
            background-color: rgb(223, 55, 83);
            color: white;
        }

        /* Header Styling */
        .header {
            width: 80%;
            background: #fefefe;
            display: flex;
            flex-direction: column;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Welcome and Search Section */
        .welcome-search-container {
            padding: 25px;
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            margin-left: -20px;
            margin-right: -20px;
            border-radius: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100px;
            margin-top: -20px;
        }

        .welcome-section h1 {
            color: #d15;
            font-size: 30px;
            letter-spacing: 1px;
            margin: 0;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-bar input {
            padding: 12px 25px;
            border: 2px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 16px;
        }

        .search-bar button {
            padding: 10px 14px;
            border: none;
            border-radius: 50%;
            background: #ff7a7a;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fff;
            margin:  10px auto;
            padding: 10px;
            border-radius: 8px;
            width: 50%;
            max-height: 90%; 
            max-width: 500px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            position: absolute;
            right: 10px;
            top: 10px;
        }

        .close:hover,
        .close:focus {
            color: black;
        }

        /* Button Styles */
        .add-service-btn {
            background-color: #ff7a7a; /* Similar to the search button color */
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease;
        }

        .add-service-btn:hover {
            background-color: #f55; /* Slightly darker shade for hover effect */
        }

        /* Button positioning inside the header */
        .add-service-btn-container {
            display: flex;
            justify-content: flex-end;
        }

        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #f4f4f4;
        }

        td a {
            color: #4CAF50;
            text-decoration: none;
        }

        td a:hover {
            text-decoration: underline;
        }

        /* Input & Textarea Styling for the Modal */
        input[type="text"],
        input[type="number"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 15px;
        }

        textarea {
            resize: vertical;
            height: 120px;
        }

        /* Submit Button Style for Modal */
        .modal button[type="submit"] {
            background-color: #ff7a7a; /* Same as "Add Service" button */
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: background-color 0.3s ease;
        }

        .modal button[type="submit"]:hover {
            background-color: #f55; /* Hover effect similar to outside button */
        }
        
/* Add margin-top to service type dropdown */
#service_type {
    margin-top: 20px;
}

/* Center the submit button and add hover effect */
.submit-btn {
    display: block;
    margin: 20px auto 0;
    padding: 10px 20px;
    background-color: #4CAF50; /* Green color */
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

.submit-btn:hover {
    background-color: #45a049; /* Darker green when hovered */
}
/* Edit and Delete Button Styles */
a {
    text-decoration: none;
    padding: 8px 16px;
    border-radius: 5px;
    font-weight: bold;
    transition: background-color 0.3s, color 0.3s;
    display: inline-block;
}

.section-heading{
    margin-top:20px;
}
    </style>
</head>
<body>
    <div class="sidebar">
    <div class="profile">
            <div class="profile-icon">
                <img src="../images/adminlogo.png" alt="Admin Logo" width="80" height="80">
            </div>
            <p>ADMINISTRATOR</p>
        </div>
        <ul class="menu">
            <li><a href="adminDash.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="admin_order.php"><i class="fas fa-box"></i> Orders</a></li>
            <li><a href="admin_inventory.php"><i class="fas fa-cogs"></i> Inventory</a></li>
            <li><a href="admin_service.php"><i class="fas fa-cogs"></i> Services Customization</a></li>
            <li><a href="admin_payment.php"><i class="fas fa-credit-card"></i> Payment Tracking</a></li>
            <li><a href="admin_promotion.php"><i class="fas fa-bullhorn"></i> Promotion</a></li>
            <li><a href="admin_delivery.php"><i class="fas fa-truck"></i> Delivery</a></li>
            <li><a href="admin_user_account.php"><i class="fas fa-user-cog"></i> User Account Management</a></li>
            <li><a href="#" onclick="confirmLogout(); return false;"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    </div>

    <div class="header">
        <div class="welcome-search-container">
            <div class="welcome-section">
                <h1>WELCOME ADMIN!</h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search">
                <button>🔍</button>
            </div>
        </div>
        <main class="content">
            <header class="section-header">
                <h2 class="section-heading">Services Customization</h2>
                <div class="add-service-btn-container">
                    <button class="add-service-btn" onclick="document.getElementById('addServiceModal').style.display='block'">
                        Add Service
                    </button>
                </div>
            </header>

            <!-- Services Table -->
            <table>
    <thead>
        <tr>
            <th>Service Type</th>
            <th>Customization Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($services as $service) { ?>
            <tr>
                <td><?php echo $service['service_type']; ?></td>
                <td><?php echo $service['customization_name']; ?></td>
                <td><?php echo $service['customization_description']; ?></td>
                <td><?php echo $service['price']; ?></td>
                <td>
                    <a href="#" class="edit-btn" 
                       data-id="<?php echo $service['customization_id']; ?>"
                       data-type="<?php echo $service['service_type']; ?>"
                       data-name="<?php echo $service['customization_name']; ?>"
                       data-description="<?php echo $service['customization_description']; ?>"
                       data-price="<?php echo $service['price']; ?>"
                       onclick="openEditModal(event)">Edit</a> |
                    <a href="admin_service.php?delete_id=<?php echo $service['customization_id']; ?>" 
                       onclick="return confirm('Are you sure you want to delete this service?')">Delete</a>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>

<!-- Edit Service Modal HTML -->
<div id="editModal" class="modal">
    <div class="modal-content">
        <h2>Edit Service</h2>
        <form action="admin_service.php" method="POST" id="editServiceForm">
            <input type="hidden" name="customization_id" id="customization_id">
            
            <label for="service_type">Service Type</label>
            <input type="text" id="service_type" name="service_type" required>

            <label for="customization_name">Customization Name</label>
            <input type="text" id="customization_name" name="customization_name" required>

            <label for="customization_description">Description</label>
            <textarea id="customization_description" name="customization_description" required></textarea>

            <label for="price">Price</label>
            <input type="number" id="price" name="price" required>

            <button type="submit" name="update_service">Save Changes</button>
        </form>
    </div>
</div>

<!-- Add New Service Modal -->
<div id="addServiceModal" class="modal">
    <div class="modal-content">
        <h2>Add New Service</h2>
        <form method="POST" class="service-form">
            <label for="service_type">Service Type:</label>
            <select id="service_type" name="service_type" required>
                <option value="Print documents">Printing Documents</option>
                <option value="Hardbound Printing">Hardbound Printing</option>
            </select><br><br>

            <label for="customization_name">Customization Name:</label>
            <input type="text" id="customization_name" name="customization_name" required><br><br>

            <label for="customization_description">Description:</label>
            <textarea id="customization_description" name="customization_description"></textarea><br><br>

            <label for="price">Price:</label>
            <input type="number" step="0.01" id="price" name="price"><br><br>

            <button type="submit" name="add_service" class="submit-btn">Add Service</button>
        </form>
    </div>
</div>

<script>
    // Function to open the edit modal and populate with service data
    function openEditModal(event) {
        event.preventDefault();

        const btn = event.target;
        const modal = document.getElementById("editModal");

        // Fill the modal with the clicked service's data
        document.getElementById("customization_id").value = btn.getAttribute('data-id');
        document.getElementById("service_type").value = btn.getAttribute('data-type');
        document.getElementById("customization_name").value = btn.getAttribute('data-name');
        document.getElementById("customization_description").value = btn.getAttribute('data-description');
        document.getElementById("price").value = btn.getAttribute('data-price');

        // Show the modal
        modal.style.display = "block";
    }

    // Function to close the modal
    function closeModal(modal) {
        modal.style.display = "none";
    }

    // Modal close behavior when clicking outside of modal content
    window.onclick = function(event) {
        const editModal = document.getElementById("editModal");
        const addServiceModal = document.getElementById("addServiceModal");

        // Close the edit modal if clicked outside
        if (event.target === editModal) {
            closeModal(editModal);
        }

        // Close the add service modal if clicked outside
        if (event.target === addServiceModal) {
            closeModal(addServiceModal);
        }
    };
</script>
<script>
        function confirmLogout() {
            // Display confirmation message
            var confirmation = confirm("Are you sure you want to log out?");
            
            // Check user response
            if (confirmation) {
                alert("You have successfully logged out.");
                // Redirect to the logout or login page
                window.location.href = "admin_login.php";
            } else {
                alert("Logout cancelled.");
            }
        }
</script>


</body>
</html>
