<?php
// Including database connection
include('../included/db_conn.php');

// Delete expired coupons
$current_date = date('Y-m-d');
$delete_sql = "DELETE FROM promotion_tbl WHERE expiry_date < '$current_date'";
$conn->query($delete_sql);

// Add this inside your PHP block after the coupon creation logic
$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['create_coupon'])) {
    $coupon_code = $_POST['coupon_code'];
    $discount_value = $_POST['discount_value'];
    $expiry_date = $_POST['expiry_date'];

    // Insert new coupon into the promotion_tbl
    $insert_sql = "INSERT INTO promotion_tbl (coupon_code, discount_value, expiry_date) 
                   VALUES ('$coupon_code', '$discount_value', '$expiry_date')";
    
    if ($conn->query($insert_sql) === TRUE) {
        $message = "Coupon created successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
}


// Fetch and display coupons from promotion_tbl
$sql = "SELECT * FROM promotion_tbl";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <title>Admin Promotion</title>
    <style>
     * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 20%;
            background: linear-gradient(to bottom, #f8d8ff, #fefbbf);
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .profile {
            text-align: center;
        }

        .profile-icon img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: pink;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .profile p {
            margin-top: 10px;
            font-weight: bold;
            font-size: 18px;
            color: #555;
        }

        .menu {
            list-style: none;
            width: 100%;
            padding: 0;
        }

        .menu li {
            margin: 15px 0;
            text-align: left;
        }

        .menu li a {
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 15px;
            color: black;
            background: #fff;
            transition: background-color 0.3s, color 0.3s;
        }

        .menu li a img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #f5f5f5;
            padding: 5px;
        }

        .menu li a:hover {
            background-color: rgb(223, 55, 83);
            color: white;
        }

        /* Header Styling */
        .header {
            width: 80%;
            background: #fefefe;
            display: flex;
            flex-direction: column;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Combined Welcome and Search Section */
        .welcome-search-container {
            padding: 25px;
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            margin-left: -20px;
            margin-right: -20px;
            border-radius: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100px;
            margin-top: -20px;
        }

        .welcome-section h1 {
            color: #d15;
            font-size: 30px;
            letter-spacing: 1px;
            margin: 0;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-bar input {
            padding: 12px 25px;
            border: 2px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 16px;
        }

        .search-bar button {
            padding: 10px 14px;
            border: none;
            border-radius: 50%;
            background: #ff7a7a;
            color: #fff;
            font-size: 18px;
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Coupon Form Styling */
        .coupon-form {
            margin-top: 30px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 10px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .coupon-form input, .coupon-form button {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }

        .coupon-form button {
            background-color: #ff7a7a;
            color: white;
            font-weight: bold;
        }

        .coupon-list table {
            width: 100%;
            margin-top: 20px;
            border-collapse: collapse;
        }

        .coupon-list th, .coupon-list td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }

        .coupon-list th {
            background-color: #f8f8f8;
        }
        .coupons-table{
            margin-top:20px;
        }
        .h2{
            margin-bottom:20px;  
        }
        .coupon-form h2 {
    display: inline-block;
    margin-right: 20px;
}

.success-message {
    display: inline-block;
    font-size: 16px;
    color: green;
    font-weight: bold;
    vertical-align: middle;
    margin-left: 10px;
}

    </style>
</head>
<body>
    <div class="sidebar">
        <div class="profile">
            <div class="profile-icon">
                <img src="../images/adminlogo.png" alt="Admin Logo" width="80" height="80">
            </div>
            <p>ADMINISTRATOR</p>
        </div>
        <ul class="menu">
            <li><a href="adminDash.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="admin_order.php"><i class="fas fa-box"></i> Orders</a></li>
            <li><a href="admin_inventory.php"><i class="fas fa-cogs"></i> Inventory</a></li>
            <li><a href="admin_service.php"><i class="fas fa-cogs"></i> Services Customization</a></li>
            <li><a href="admin_payment.php"><i class="fas fa-credit-card"></i> Payment Tracking</a></li>
            <li><a href="admin_promotion.php"><i class="fas fa-bullhorn"></i> Promotion</a></li>
            <li><a href="admin_delivery.php"><i class="fas fa-truck"></i> Delivery</a></li>
            <li><a href="admin_user_account.php"><i class="fas fa-user-cog"></i> User Account Management</a></li>
            <li><a href="#" onclick="confirmLogout(); return false;"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    
    <div class="header">
        <!-- Combined Section -->
        <div class="welcome-search-container">
            <div class="welcome-section">
                <h1>WELCOME ADMIN!</h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search">
                <button>🔍</button>
            </div>
        </div>
        
        <!-- Start of Content -->
        <div class="coupon-form">
        <h2>Create Coupon/Promo
        <?php if ($message) { echo '<span class="success-message">' . $message . '</span>'; } ?></h2>
            <form method="POST">
                <label for="coupon_code">Coupon Code:</label>
                <input type="text" id="coupon_code" name="coupon_code" required placeholder="Enter coupon code" />

                <label for="discount_value">Discount Value (in %):</label>
                <input type="number" id="discount_value" name="discount_value" required placeholder="Enter discount percentage" min="1" max="100" />

                <label for="expiry_date">Expiry Date:</label>
                <input type="date" id="expiry_date" name="expiry_date" required />

                <button type="submit" name="create_coupon">Create Coupon</button>
            </form>
        </div>

        <div class="coupon-list">
            <h2 class="coupons-table">Available Coupons</h2>
            <table>
                <thead>
                    <tr>
                        <th>Coupon Code</th>
                        <th>Discount Value (%)</th>
                        <th>Expiry Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Loop through the coupons and display them
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['coupon_code'] . "</td>";
                        echo "<td>" . $row['discount_value'] . "</td>";
                        echo "<td>" . $row['expiry_date'] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        <!-- End of Content -->
    </div>
    <script>
        function confirmLogout() {
            // Display confirmation message
            var confirmation = confirm("Are you sure you want to log out?");
            
            // Check user response
            if (confirmation) {
                alert("You have successfully logged out.");
                // Redirect to the logout or login page
                window.location.href = "admin_login.php";
            } else {
                alert("Logout cancelled.");
            }
        }
</script>

</body>
</html>
