<?php
session_start();  // Start session to manage user authentication

// Include database connection
include('../included/db_conn.php');

// Fetch all orders from cart_tbl
$sql = "SELECT order_id, name, service_type, created_at FROM cart_tbl";
$result = $conn->query($sql);

// Check if there are any orders
$cartData = [];
if ($result->num_rows > 0) {
    // Store all orders in an array
    while ($row = $result->fetch_assoc()) {
        $cartData[] = $row;
    }
}

// Handle order approval (if 'approve' button is clicked)
if (isset($_GET['approve_id'])) {
    $order_id = $_GET['approve_id'];
    $approve_sql = "UPDATE cart_tbl SET status = 'Approved' WHERE order_id = $order_id";
    if ($conn->query($approve_sql) === TRUE) {
        echo "<script>
                alert('Order approved successfully');
                window.location.href = 'admin_order.php';
              </script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Handle viewing the order (if 'view' button is clicked)
if (isset($_GET['view_id'])) {
    $order_id = $_GET['view_id'];
    // Fetch the specific order details
    $view_sql = "SELECT * FROM cart_tbl WHERE order_id = $order_id";
    $view_result = $conn->query($view_sql);
    $order_details = $view_result->fetch_assoc();
    // You can display this information on a new page or in a modal.
    echo "<pre>" . print_r($order_details, true) . "</pre>";  // For testing purpose
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <title>Admin Orders</title>
    <style>
        /* Reset and Basic Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styling */
        .sidebar {
            width: 20%;
            background: linear-gradient(to bottom, #f8d8ff, #fefbbf);
            padding: 20px 10px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 20px;
        }

        .profile {
            text-align: center;
        }

        .profile-icon img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: pink;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .profile p {
            margin-top: 10px;
            font-weight: bold;
            font-size: 18px;
            color: #555;
        }

        .menu {
            list-style: none;
            width: 100%;
            padding: 0;
        }

        .menu li {
            margin: 15px 0;
            text-align: left;
        }

        .menu li a {
            display: flex;
            align-items: center;
            gap: 15px;
            text-decoration: none;
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 15px;
            color: black;
            background: #fff;
            transition: background-color 0.3s, color 0.3s;
        }

        .menu li a img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            background: #f5f5f5;
            padding: 5px;
        }

        .menu li a:hover {
            background-color: rgb(223, 55, 83);
            color: white;
        }

        /* Header Styling */
        .header {
            width: 80%;
            background: #fefefe;
            display: flex;
            flex-direction: column;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        /* Combined Welcome and Search Section */
        .welcome-search-container {
            padding: 25px;
            /* Increased padding */
            background: linear-gradient(to right, #ff9a9e, #fad0c4);
            margin-left: -20px;
            margin-right: -20px;
            border-radius: 1px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 100px;
            /* Adjusted height for more space */
            margin-top: -20px;
            /* Shift the container upwards */
        }

        .welcome-section h1 {
            color: #d15;
            font-size: 30px;
            /* Increased font size for emphasis */
            letter-spacing: 1px;
            margin: 0;
        }

        .search-bar {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-bar input {
            padding: 12px 25px;
            /* Adjust padding for larger input field */
            border: 2px solid #ddd;
            border-radius: 20px;
            outline: none;
            font-size: 16px;
            /* Adjust font size for better readability */
        }

        .search-bar button {
            padding: 10px 14px;
            border: none;
            border-radius: 50%;
            background: #ff7a7a;
            color: #fff;
            font-size: 18px;
            /* Increased button icon size */
            cursor: pointer;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .approval-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .approval-table th,
        .approval-table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        .approval-table th {
            background-color: #f4f4f4;
        }

        .approval-table td a {
            color: #4CAF50;
            text-decoration: none;
        }

        .approval-table td a:hover {
            text-decoration: underline;
        }

        .section-heading {
            margin-top: 20px;
        }
        /* Navbar container */
.navbar {
    width: 100%;
    padding: 10px 0;
    background-color: #d15;
}

/* Unordered list for nav items */
.navbar ul {
    list-style: none;
    text-align: center;
   
}

/* Navbar links */
.navbar ul li {
    display: inline-block;
    margin: 0 20px;
    
}

/* Style for links */
.navbar ul li a {
    text-decoration: none;
    color: #fff; /* White text color */
    font-size: 16px;
    padding: 10px 20px;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

/* Hover effect for links */
.navbar ul li a:hover {
    background-color: #ddd; /* Light background color on hover */
    color: #333; /* Dark color for the text on hover */
}

/* Media query for smaller screens (mobile) */
@media (max-width: 768px) {
    .navbar ul {
        padding: 0;
    }
    .navbar ul li {
        display: block;
        margin: 10px 0;
    }
}
    </style>
</head>

<body>
    <div class="sidebar">
        <div class="profile">
            <div class="profile-icon">

                <img src="../images/adminlogo.png" alt="Admin Logo" width="80" height="80">
            </div>
            <p>ADMINISTRATOR</p>
        </div>
        <ul class="menu">
            <li><a href="adminDash.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="admin_order.php"><i class="fas fa-box"></i> Orders</a></li>
            <li><a href="admin_inventory.php"><i class="fas fa-cogs"></i> Inventory</a></li>
            <li><a href="admin_service.php"><i class="fas fa-cogs"></i> Services Customization</a></li>
            <li><a href="admin_payment.php"><i class="fas fa-credit-card"></i> Payment Tracking</a></li>
            <li><a href="admin_promotion.php"><i class="fas fa-bullhorn"></i> Promotion</a></li>
            <li><a href="admin_delivery.php"><i class="fas fa-truck"></i> Delivery</a></li>
            <li><a href="admin_user_account.php"><i class="fas fa-user-cog"></i> User Account Management</a></li>
            <li><a href="#" onclick="confirmLogout(); return false;"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    <div class="header">
        <!-- Combined Section -->
        <div class="welcome-search-container">
            <div class="welcome-section">
                <h1>WELCOME ADMIN!</h1>
            </div>
            <div class="search-bar">
                <input type="text" placeholder="Search">
                <button>🔍</button>
            </div>
        </div>

        
        <!--Start ot content-->
        <main class="content">
            
            <nav class="navbar">
            <ul>
                <li><a href="admin_order.php">Print Document</a></li>
                <li><a href="admin_orderflyers.php">Flyer</a></li>
                <li><a href="admin_ordersticker.php">Stickers</a></li>
                <li><a href="admin_orderinvi.php">Invitation Cards</a></li>
                <li><a href="admin_orderidpic.php">ID Picture</a></li>
                <li><a href="admin_orderinstax.php">Instax Photo</a></li>
                <li><a href="admin_ordersintra.php">Photo Sintra Board</a></li>
            </ul>
            </nav>

            <main class="content">
            <header class="section-header">
                <h2>Print Document Order Lists</h2>
            </header>
            <table class="approval-table">
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Customer Name</th>
                        <th>Service Type</th>
                        <th>Status</th>
                        <th>Order Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                foreach ($cartData as $cart) {
                    echo "<tr id='order-{$cart['order_id']}'>
                        <td>{$cart['order_id']}</td>
                        <td>" . htmlspecialchars($cart['name']) . "</td>
                        <td>" . htmlspecialchars($cart['service_type']) . "</td>
                        <td>" . (isset($cart['status']) ? htmlspecialchars($cart['status']) : 'Pending') . "</td>
                        <td>" . ($cart['created_at'] ? htmlspecialchars($cart['created_at']) : 'Not Set') . "</td>
                        <td>
                            <a href='admin_order.php?approve_id={$cart['order_id']}'>Approve</a> | 
                            <a href='admin_order.php?view_id={$cart['order_id']}'>View</a>
                        </td>
                    </tr>";
                }
                ?>
                </tbody>
            </table>
        </main>
        <!--End of Code of Content-->
    </div>
    <script>
        function confirmLogout() {
            // Display confirmation message
            var confirmation = confirm("Are you sure you want to log out?");

            // Check user response
            if (confirmation) {
                alert("You have successfully logged out.");
                // Redirect to the logout or login page
                window.location.href = "admin_login.php";
            } else {
                alert("Logout cancelled.");
            }
        }
    </script>

</body>

</html>